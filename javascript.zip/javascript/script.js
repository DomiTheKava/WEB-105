/* https://www.w3schools.com/js/tryit.asp?filename=tryjs_intro_lightbulb */


/* change image */

function change(picture){
    document.getElementById("large").src = picture;
}


